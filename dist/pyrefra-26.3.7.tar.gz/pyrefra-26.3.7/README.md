# PyRefra

<img src="https://github.com/HZeyen/PyRefra/blob/main/PyRefra_Logo.png" alt="pyrefra" width="200"/>
Software package for treatment and tomography of multishot refraction seismic data. Working under Linux and Windows OS.

This program has doi number 10.5281/zenodo.10728121. When using, please cite the following publication:

Zeyen, H. and Léger, E. (2024): PyRefra – Refraction seismic data treatment and inversion. Computers & Geosciences, 185, 105556; doi: 10.1016/j.cageo.2024.105556

For installation instructions see [1. Installation instructions](./1_Installation.md).

Once installed, you can test and get familiar with the codes by using the data in the [example](./Example) folder. See the [README](./Example/README.md) file there.

For preparing your own dataset, [2_Data_preparation.md](./2_Data_preparation.md) describes file naming conventions and necessary geometry files.


The main manual describing menu entries and other options is located in file [PyRefra_manual.pdf](./doc/PyRefra_manual.pdf). **It is this file which describes always the last version.** No guaranty that the above mentioned online version (.md files) is completely up to date, since it is more difficult to maintain. A user's guide [PyRefra_guide.pdf](./doc/PyRefra_guide.pdf) takes the opposite approach, explaining how to work with pyrefra.

Thanks to my son Manuel Zeyen for creating the new icon !
